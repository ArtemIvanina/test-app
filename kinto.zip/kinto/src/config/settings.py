import os
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseModel):
    sqlite_db_password: str = os.getenv("SQLITE_DB_PASSWORD", 'pass')
    sqlite_db_path: str = os.getenv('SQLITE_DB_PATH', 'test.db')
    sqlalchemy_database_url: str = f"sqlite:///{sqlite_db_path}?key={sqlite_db_password}"

    # url = f'sqlite3://?{username}:{password}@{domain}:{port}/{database_name}'

    jwt_token: str = os.getenv("JWTOKEN", "")
    
    secret_key: str = os.getenv("SECRET_KEY", 'secret_key')
    refresh_token_time: int = os.getenv("REFRESH_TOKEN", 3000)
    algorithm: str = os.getenv("ALGORITHM", 'HS256')
    
    mail_username: str = os.getenv("MAIL_USERNAME", 'example@mail.com')
    mail_password: str = os.getenv("MAIL_PASSWORD", 'password')
    mail_from: str = os.getenv("MAIL_FROM", 'example@mail.com')
    mail_port: int = os.getenv("MAIL_PORT", 465)
    mail_server: str = os.getenv("MAIL_SERVER", 'smtp.meta.ua')

    class Config:
        env_file = '.env'
        env_file_encoding = 'utf-8'

settings = Settings()
