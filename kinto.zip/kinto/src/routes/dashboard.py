from fastapi import APIRouter, Request, status, HTTPException, Depends, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.repository import rp_slides, rp_settings, rp_stocks, rp_propositions, rp_categories
from src.services.authorization import auth_service


router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')



@router.get("")
async def dashboard(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)


    slides = rp_slides.get_slides(db)
    stocks = rp_stocks.get_stocks(db)
    propositions = rp_propositions.get_propositions(db)
    categories = rp_categories.get_categories(db)


    return templates.TemplateResponse(
        "pages/crm/index.html",
        context={
            "request": request,
            "current_page": "dashboard",
            "title": f"{configuration.brand_name}[CRM] - Dashboard",
            "configuration": configuration,
            "user": current_user,
            "slides": slides,
            "stocks": stocks,
            "propositions": propositions,
            "categories": categories
        }
    )