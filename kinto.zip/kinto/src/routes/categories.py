from fastapi import APIRouter, Request, status, HTTPException, Depends, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.schemas.categories_schema import CategoryModel
from src.repository import rp_categories, rp_settings
from src.services.authorization import auth_service


router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')


# CATEGORIES
@router.get("/categories")
async def categories_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    message = request.session.pop('message', '')

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    categories = rp_categories.get_categories(db)

    return templates.TemplateResponse(
        "pages/crm/categories/categories.html",
        context={
            "request": request,
            "current_page": "categories",
            "title": f"{configuration.brand_name}[CRM] - Categories",
            "message": message,
            "categories": categories,
            "configuration": configuration
        }
    )

# ADD CATEGORY
@router.get("/categories/add-category")
async def add_category_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    categories = rp_categories.get_categories(db)

    return templates.TemplateResponse(
        "pages/crm/categories/add-category.html",
        context={
            "request": request,
            "current_page": "categories",
            "title": f"{configuration.brand_name}[CRM] - Add category",
            "categories": categories,
            "configuration": configuration
        }
    )


# CREATE CATEGORY POST
@router.post("/categories/add-category/create")
async def create_slides(
    request: Request,
    category: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    new_category = CategoryModel(
        category=category.lower()
    )
    
    category = rp_categories.create_category(new_category, db)
    request.session['message'] = 'Category was successfully created!'

    return RedirectResponse(url="/crm/categories", status_code=status.HTTP_302_FOUND)


# UPDATE CATEGORY GET
@router.get("/categories/{category_id}/")
async def update_category_page(
    request: Request,
    category_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    categories = rp_categories.get_categories(db)
    category = rp_categories.get_category_by_id(category_id, db)
    if not category:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    return templates.TemplateResponse(
        "pages/crm/categories/update-category.html",
        context={
            "request": request,
            "current_page": "categories",
            "title": f"{configuration.brand_name}[CRM] - Update category",
            "category": category,
            "categories": categories,
            "configuration": configuration
        }
    )

# UPDATE CATEGORY POST
@router.post("/categories/{category_id}/update")
async def create_slides(
    request: Request,
    category_id: int,
    category: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    new_category = CategoryModel(
        category=category
    )
    
    category = rp_categories.update_category(category_id, new_category, db)
    request.session['message'] = 'Category was successfully updated!'

    return RedirectResponse(url="/crm/categories", status_code=status.HTTP_302_FOUND)



# DELETE CATEGORY
@router.get("/categories/{category_id}/delete")
async def delete_slide_page(
    request: Request,
    category_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    category = rp_categories.get_category_by_id(category_id, db)
    if category:
        rp_categories.delete_category_by_id(category.id, db)

        request.session['message'] = 'Category was successfully deleted!'
        return RedirectResponse(url="/crm/categories", status_code=status.HTTP_302_FOUND)