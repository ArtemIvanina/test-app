from fastapi import APIRouter, Request, status, HTTPException, Depends, Form, UploadFile, File
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.repository import rp_settings, rp_users
from src.schemas.navigations_schema import NavigationModel
from src.schemas.application_settings_schema import AppGeneralModel, AppFooterModel, AppHeaderModel, AppMapModel, AppPreviewModel, AppPropositionButtonModel
from src.services.authorization import auth_service
from src.utilities.image_actions import save_image, delete_old_image


router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')


# SETTINGS PAGE
@router.get("/settings")
async def settings_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   
    
    message = request.session.pop('message', '')
    navigations = rp_settings.get_navigation(db)

    return templates.TemplateResponse(
        "pages/crm/settings/settings.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Settings",
            "message": message,
            "navigations": navigations,
            "configuration": configuration,
            "user": current_user
        }
    )

# CHANGE LOGIN CONFIRMATION
@router.get("/settings/change-login-confirmation")
async def change_login_confirmation_get(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   
    
    rp_users.update_login_confirmation(current_user, db)
    request.session['message'] = 'Login confirmation was successfully changed!'
    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)




# NAVIGATION CREATE GET
@router.get("/settings/navigation/create")
async def navigation_create(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    return templates.TemplateResponse(
        "pages/crm/settings/add-navigation.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Create navigation",
            "configuration": configuration
        }
    )
# NAVIGATION CREATE POST
@router.post("/settings/add-navigation/create")
async def navigation_create_post(
    request: Request,
    link_text: str = Form(...),
    link_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   
    
    new_navigation = NavigationModel(
        link_text=link_text,
        link_url=link_url
    )
    
    navigation = rp_settings.create_navigation(new_navigation, db)
    request.session['message'] = 'Navigation was successfully add!'

    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)


# NAVIGATION UPDATE GET
@router.get("/settings/navigation/{navigation_id}/")
async def update_navigation_page(
    request: Request,
    navigation_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    navigation = rp_settings.get_navigation_by_id(navigation_id, db)

    if not navigation:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    return templates.TemplateResponse(
        "pages/crm/settings/update-navigation.html",
        context={
            "request": request,
            "current_page": "slides",
            "title": f"{configuration.brand_name}[CRM] - Update navigation",
            "navigation": navigation,
            "configuration": configuration
        }
    )

# NAVIGATION UPDATE POST
@router.post("/settings/navigation/{navigation_id}/update")
async def update_navigation_page(
    request: Request,
    navigation_id: int,
    link_text: str = Form(...),
    link_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    new_navigation = NavigationModel(
        link_text=link_text,
        link_url=link_url
    )
    
    navigation = rp_settings.update_navigation(navigation_id, new_navigation, db)
    request.session['message'] = 'Navigation was successfully updated!'

    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)

# DELETE NAVIGATION
@router.get("/settings/{navigation_id}/delete")
async def delete_slide_page(
    request: Request,
    navigation_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   
    
    navigation = rp_settings.get_navigation_by_id(navigation_id, db)
    if navigation:
        rp_settings.delete_navigation_by_id(navigation.id, db)

        request.session['message'] = f'{navigation.link_text} from navigation was successfully deleted!'
        return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)
    
# UPDATE SYSTEM GET
@router.get("/settings/update-system")
async def update_system_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    return templates.TemplateResponse(
        "pages/crm/settings/updates/update-system.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Update general",
            "configuration": configuration
        }
    )

# UPDATE SYSTEM POST
@router.post("/settings/update-system")
async def update_system_page(
    request: Request,
    currency: str = Form(...),
    brand_name: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    new_general = AppGeneralModel(
        currency=currency,
        brand_name=brand_name
    )
    
    system = rp_settings.update_general(new_general, db)
    request.session['message'] = 'General was successfully saved!'

    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)

# UPDATE HEADER GET
@router.get("/settings/update-header")
async def update_header_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    return templates.TemplateResponse(
        "pages/crm/settings/updates/update-header.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Update header",
            "configuration": configuration
        }
    )

# UPDATE HEADER POST
@router.post("/settings/update-header")
async def update_header_page(
    request: Request,
    header_button_text: str = Form(...),
    header_button_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    new_header = AppHeaderModel(
        header_button_text=header_button_text,
        header_button_url=header_button_url
    )
    
    header = rp_settings.update_header(new_header, db)
    request.session['message'] = 'Header was successfully saved!'

    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)



# UPDATE PREVIEW GET
@router.get("/settings/update-preview")
async def update_preview_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    return templates.TemplateResponse(
        "pages/crm/settings/updates/update-preview.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Update preview",
            "configuration": configuration
        }
    )

# UPDATE PREVIEW POST
@router.post("/settings/update-preview")
async def update_preview_page(
    request: Request,
    preview_image: UploadFile | str = File('...'),
    preview_title: str = Form(...),
    preview_description: str = Form(""),
    preview_button_text: str = Form(...),
    preview_button_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    UPLOAD_DIR = "static/images/uploads/preview"

    if isinstance(preview_image, str):
        if preview_image == '':
            image_path = configuration.preview_image
    else:
        if preview_image.filename == '':
            image_path = configuration.preview_image
        else:
            delete_old_image(configuration.preview_image)
            image_path = save_image(UPLOAD_DIR, preview_image)

    new_preview = AppPreviewModel(
        preview_image=image_path,
        preview_title=preview_title,
        preview_description=preview_description,
        preview_button_text=preview_button_text,
        preview_button_url=preview_button_url
    )
    
    preview = rp_settings.update_preview(new_preview, db)
    request.session['message'] = 'Preview was successfully saved!'

    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)



# UPDATE FOOTER GET
@router.get("/settings/update-footer")
async def update_footer_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    return templates.TemplateResponse(
        "pages/crm/settings/updates/update-footer.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Update footer",
            "configuration": configuration
        }
    )

# UPDATE FOOTER POST
@router.post("/settings/update-footer")
async def update_footer_page(
    request: Request,
    footer_contact_us_location_text: str = Form(...),
    footer_contact_us_location_url: str = Form('...'),
    footer_contact_us_call_text: str = Form(...),
    footer_contact_us_call_url: str = Form('...'),
    footer_contact_us_mail_text: str = Form(...),
    footer_contact_us_mail_url: str = Form('...'),
    footer_social_description: str = Form('...'),
    footer_shedule_days_text: str = Form('...'),
    footer_shedule_time_text: str = Form('...'),
    footer_copyright_text: str = Form('...'),
    powered_by_text: str = Form('...'),
    powered_by_url: str = Form('...'),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    new_footer = AppFooterModel(
        footer_contact_us_location_text=footer_contact_us_location_text,
        footer_contact_us_location_url=footer_contact_us_location_url,
        footer_contact_us_call_text=footer_contact_us_call_text,
        footer_contact_us_call_url=footer_contact_us_call_url,
        footer_contact_us_mail_text=footer_contact_us_mail_text,
        footer_contact_us_mail_url=footer_contact_us_mail_url,
        footer_social_description=footer_social_description,
        footer_shedule_days_text=footer_shedule_days_text,
        footer_shedule_time_text=footer_shedule_time_text,
        footer_copyright_text=footer_copyright_text,
        powered_by_text=powered_by_text,
        powered_by_url=powered_by_url,
    )
    
    footer = rp_settings.update_footer(new_footer, db)
    request.session['message'] = 'Footer was successfully saved!'

    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)

# UPDATE MAP GET
@router.get("/settings/update-map")
async def update_map_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    return templates.TemplateResponse(
        "pages/crm/settings/updates/update-map.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Update map",
            "configuration": configuration
        }
    )

# UPDATE MAP POST
@router.post("/settings/update-map")
async def update_map_page(
    request: Request,
    map_api_key: str = Form('...'),
    map_coordinate_latitude: str = Form('...'),
    map_coordinate_longitude: str = Form('...'),
    map_zoom: str = Form('...'),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    new_map = AppMapModel(
        map_api_key=map_api_key,
        map_coordinate_latitude=map_coordinate_latitude,
        map_coordinate_longitude=map_coordinate_longitude,
        map_zoom=map_zoom
    )
    
    map = rp_settings.update_map(new_map, db)
    request.session['message'] = 'Map was successfully saved!'

    return RedirectResponse(url="/crm/settings", status_code=status.HTTP_302_FOUND)



# UPDATE PROPOSITION BUTTON GET
@router.get("/settings/update-proposition-button")
async def update_proposition_button_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    return templates.TemplateResponse(
        "pages/crm/settings/updates/update-proposition-button.html",
        context={
            "request": request,
            "current_page": "settings",
            "title": f"{configuration.brand_name}[CRM] - Update proposition button",
            "configuration": configuration
        }
    )

# UPDATE MAP POST
@router.post("/settings/update-proposition-button")
async def update_proposition_button_page(
    request: Request,
    propositions_button_text: str = Form(...),
    propositions_button_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    new_proposition_button = AppPropositionButtonModel(
        propositions_button_text=propositions_button_text,
        propositions_button_url=propositions_button_url
    )
    
    proposition_button = rp_settings.update_proposition_button(new_proposition_button, db)
    request.session['message'] = 'Proposition button was successfully saved!'

    return RedirectResponse(url="/crm/propositions", status_code=status.HTTP_302_FOUND)