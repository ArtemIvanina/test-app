from fastapi import APIRouter, Request, status, HTTPException, BackgroundTasks, Depends, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.schemas.users_schema import UserModel
from src.schemas.application_settings_schema import AplicationSettingsModel
from src.services.authorization import auth_service
from src.repository import rp_users, rp_settings
from src.config.settings import settings
from src.services.email import send_email_login_confirmation
from src.utilities.crm_generator import generate_secret_key


router = APIRouter(prefix="/crm/auth")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')


UPLOAD_DIR = "static/images/uploads/preview"





# INIT PAGE
@router.get("/init")
async def page_init(request: Request, db: Session = Depends(get_db)):
    configuration = rp_settings.check_init(db)
    if configuration is None:
        return templates.TemplateResponse(
            "pages/crm/auth/init.html",
            context={
                "request": request,
                "title": f"NONE[CRM] - Init"
            }
        )
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)


# START INIT PAGE POST
@router.post("/start-init")
async def page_start_init_post(
    request: Request,
    brand_name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:

        password = auth_service.get_password_hash(password)
        new_user = UserModel(
            email=email,
            password=password
        )
        rp_users.create_user(new_user, db)

        
        app_settings = AplicationSettingsModel(
            currency='$',
            brand_name=brand_name,
            header_button_text="Order online",
            header_button_url="#",
            propositions_button_text="View more",
            propositions_button_url="#",
            preview_image=f"static/images/uploads/preview/about-img.png",
            preview_title="We Are Feane",
            preview_description="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All",
            preview_button_text="Read More",
            preview_button_url="#",
            map_api_key="AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI",
            map_coordinate_latitude="40.712775",
            map_coordinate_longitude="-74.005973",
            map_zoom="14",
            footer_contact_us_location_text="Location",
            footer_contact_us_location_url="#",
            footer_contact_us_call_text="Call +1 123345677",
            footer_contact_us_call_url="#",
            footer_contact_us_mail_text="domain@gmail.com",
            footer_contact_us_mail_url="#",
            footer_social_description="Necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with",
            footer_shedule_days_text="Everyday",
            footer_shedule_time_text="10.00 Am -10.00 Pm",
            footer_copyright_text="© 2024 All Rights Reserved By",
            powered_by_text="© Powered By",
            powered_by_url="#"
        )

        rp_settings.create_application_settings(app_settings, db)

        return RedirectResponse(url="/crm/auth/login", status_code=status.HTTP_302_FOUND)
    else:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

@router.post("/login")
async def page_login_post(
    request: Request, 
    background_tasks: BackgroundTasks,
    email: str = Form(...),
    password: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response

    user = rp_users.get_user_by_email(email, db)
    if user and auth_service.verify_password(password, user.password):
        refresh_token = auth_service.create_refresh_token(data={"sub": user.email}, expires_delta=int(settings.refresh_token_time))
        if user.security == True:
            
            # SECRET_KEY_CREATE
            secret_key = generate_secret_key(10)
            rp_users.update_key(user, secret_key, db)

            subject = "Login confirmation Request"
            template = "login-confirmation_template.html"
            background_tasks.add_task(send_email_login_confirmation, user.email, str(request.base_url), secret_key, subject, template)
            return RedirectResponse(url=f'/crm/auth/login-confirmation/{refresh_token}', status_code=status.HTTP_302_FOUND)
             
        
        rp_users.update_token(user, refresh_token, db)
        response = RedirectResponse(url='/crm', status_code=status.HTTP_302_FOUND)
        response.set_cookie(settings.jwt_token, value=refresh_token, httponly=True)
        return response
    
    return templates.TemplateResponse(
        "pages/crm/auth/login.html",
        context={
            "request": request,
            "title": f"{configuration.brand_name}[CRM] - Login",
            "current_user": current_user,
            "message": "Wrong Email or Password"
        }
    )

@router.get("/login-confirmation/{confirmation_token}")
async def login_confirmatiom_page(
    request: Request,
    confirmation_token: str,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response

    return templates.TemplateResponse(
        "pages/crm/auth/login-confirmation.html",
        context={
            "request": request,
            "title": f"{configuration.brand_name}[CRM] - Login Confirmation",
            "current_user": current_user,
            "configuration": configuration,
            "confirmation_token": confirmation_token,
            "message": ""
        }
    )

@router.post("/login-confirmation/{confirmation_token}")
async def login_confirmatiom_page_post(
    request: Request,
    confirmation_token: str,
    key: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    

    email = auth_service.get_email_from_token(confirmation_token)
    user = rp_users.get_user_by_email(email, db)
    
    if user.key == key:
        refresh_token = auth_service.create_refresh_token(data={"sub": user.email}, expires_delta=int(settings.refresh_token_time))
        rp_users.update_token(user, refresh_token, db)
        response = RedirectResponse(url='/crm', status_code=status.HTTP_302_FOUND)
        response.set_cookie(settings.jwt_token, value=refresh_token, httponly=True)
        return response

    
    return templates.TemplateResponse(
        "pages/crm/auth/login-confirmation.html",
        context={
            "request": request,
            "title": f"{configuration.brand_name}[CRM] - Login Confirmation",
            "current_user": current_user,
            "configuration": configuration,
            "confirmation_token": confirmation_token,
            "message": "Wrong key"
        }
    )


@router.get("/login")
async def login_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    
    return templates.TemplateResponse(
        "pages/crm/auth/login.html",
        context={
            "request": request,
            "title": f"{configuration.brand_name}[CRM] - Login",
            "current_user": current_user,
            "message": ""
        }
    )

@router.get('/logout')
async def logout(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    response = RedirectResponse(url='/', status_code=status.HTTP_302_FOUND)
    response.set_cookie(settings.jwt_token, value='', httponly=True)
    return response
    