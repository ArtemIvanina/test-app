from fastapi import APIRouter, Request, status, HTTPException, Depends, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.schemas.feedbacks_schema import FeedbackModel
from src.repository import rp_feedbacks, rp_settings
from src.services.authorization import auth_service


router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')

# FEEDBACKS
@router.get("/feedbacks")
async def feedbacks_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    message = request.session.pop('message', '')

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    feedbacks = rp_feedbacks.get_feedbacks(db)
    system = rp_settings.get_settings(db)

    return templates.TemplateResponse(
        "pages/crm/feedbacks/feedbacks.html",
        context={
            "request": request,
            "current_page": "feedbacks",
            "title": f"{configuration.brand_name}[CRM] - Feedbacks",
            "message": message,
            "feedbacks": feedbacks,
            "settings": system,
            "configuration": configuration
        }
    )

# ADD FEEDBACK
@router.get("/feedbacks/add-feedback")
async def add_feedback_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    system = rp_settings.get_settings(db)

    return templates.TemplateResponse(
        "pages/crm/feedbacks/add-feedback.html",
        context={
            "request": request,
            "current_page": "feedbacks",
            "title": f"{configuration.brand_name}[CRM] - Add feedback",
            "settings": system,
            "configuration": configuration
        }
    )


# CREATE FEEDBACK POST
@router.post("/feedbacks/add-feedback/create")
async def create_feedbacks(
    request: Request,
    username: str = Form(...),
    rating: int = Form(...),
    comment: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    
    new_feedback = FeedbackModel(
        username=username,
        rating=rating,
        comment=comment
    )

    feedback = rp_feedbacks.create_feedback(new_feedback, db)
    request.session['message'] = 'Feedback was successfully created!'

    return RedirectResponse(url="/crm/feedbacks", status_code=status.HTTP_302_FOUND)


# UPDATE FEEDBACK GET
@router.get("/feedbacks/{feedback_id}/")
async def update_feedback_page(
    request: Request,
    feedback_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    
    feedback = rp_feedbacks.get_feedback_by_id(feedback_id, db)
    if not feedback:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    return templates.TemplateResponse(
        "pages/crm/feedbacks/update-feedback.html",
        context={
            "request": request,
            "current_page": "feedbacks",
            "title": f"{configuration.brand_name}[CRM] - Update feedback",
            "feedback": feedback,
            "configuration": configuration,
        }
    )


# UPDATE FEEDBACK POST
@router.post("/feedbacks/{feedback_id}/update")
async def create_slides(
    request: Request,
    feedback_id: int,
    username: str = Form(...),
    rating: int = Form(...),
    comment: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    feedback = rp_feedbacks.get_feedback_by_id(feedback_id, db)
   
    new_feedback = FeedbackModel(
        username=username,
        rating=rating,
        comment=comment
    )
    
    feedback = rp_feedbacks.update_feedback(feedback_id, new_feedback, db)
    request.session['message'] = 'Feedback was successfully updated!'

    return RedirectResponse(url="/crm/feedbacks", status_code=status.HTTP_302_FOUND)




# DELETE FEEDBACK
@router.get("/feedbacks/{feedback_id}/delete")
async def delete_feedback_page(
    request: Request,
    feedback_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    feedback = rp_feedbacks.get_feedback_by_id(feedback_id, db)

    if feedback:
        rp_feedbacks.delete_feedback_by_id(feedback.id, db)

        request.session['message'] = 'Feedback was successfully deleted!'
        return RedirectResponse(url="/crm/feedbacks", status_code=status.HTTP_302_FOUND)