from fastapi import APIRouter, Request, status, HTTPException, Depends, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.schemas.socials_schema import SocialModel
from src.repository import rp_socials, rp_settings
from src.services.authorization import auth_service


router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')




# SLIDES
@router.get("/socials")
async def socials_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    message = request.session.pop('message', '')

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    socials = rp_socials.get_socials(db)

    return templates.TemplateResponse(
        "pages/crm/socials/socials.html",
        context={
            "request": request,
            "current_page": "socials",
            "title": f"{configuration.brand_name}[CRM] - Socials",
            "message": message,
            "socials": socials,
            "configuration": configuration
        }
    )

# ADD SOCIAL
@router.get("/socials/add-social")
async def add_social_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    return templates.TemplateResponse(
        "pages/crm/socials/add-social.html",
        context={
            "request": request,
            "current_page": "socials",
            "title": f"{configuration.brand_name}[CRM] - Add social",
            "configuration": configuration
        }
    )



# CREATE SOCIAL POST
@router.post("/socials/add-social/create")
async def create_socials(
    request: Request,
    fa_icon_class: str = Form(...),
    fa_icon_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    new_social = SocialModel(
        fa_icon_class=fa_icon_class,
        fa_icon_url=fa_icon_url
    )
    
    social = rp_socials.create_social(new_social, db)
    request.session['message'] = 'Social was successfully created!'

    return RedirectResponse(url="/crm/socials", status_code=status.HTTP_302_FOUND)



# UPDATE SOCIAL GET
@router.get("/socials/{social_id}/")
async def update_slide_page(
    request: Request,
    social_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    social = rp_socials.get_social_by_id(social_id, db)
    if not social:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    return templates.TemplateResponse(
        "pages/crm/socials/update-social.html",
        context={
            "request": request,
            "current_page": "socials",
            "title": f"{configuration.brand_name}[CRM] - Update social",
            "social": social,
            "configuration": configuration
        }
    )


# UPDATE SOCIAL POST
@router.post("/socials/{social_id}/update")
async def update_social(
    request: Request,
    social_id: int,
    fa_icon_class: str = Form(...),
    fa_icon_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    new_social = SocialModel(
        fa_icon_class=fa_icon_class,
        fa_icon_url=fa_icon_url
    )
    
    social = rp_socials.update_social(social_id, new_social, db)
    request.session['message'] = 'Social was successfully updated!'

    return RedirectResponse(url="/crm/socials", status_code=status.HTTP_302_FOUND)


# DELETE SOCIAL
@router.get("/socials/{social_id}/delete")
async def delete_social_page(
    request: Request,
    social_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    social = rp_socials.get_social_by_id(social_id, db)
    if social:
        rp_socials.delete_social_by_id(social.id, db)

        request.session['message'] = 'Social was successfully deleted!'
        return RedirectResponse(url="/crm/socials", status_code=status.HTTP_302_FOUND)
    
