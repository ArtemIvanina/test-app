from fastapi import APIRouter, Form, UploadFile, File, HTTPException, Depends, status, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.schemas.propositions_schema import PropostionModel
from src.repository import rp_propositions, rp_categories, rp_settings
from src.services.authorization import auth_service
from src.utilities.image_actions import save_image, delete_old_image

router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')


UPLOAD_DIR = "static/images/uploads/propositions"

# PROPOSITIONS
@router.get("/propositions")
async def propositions_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    message = request.session.pop('message', '')

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    propositions = rp_propositions.get_propositions(db)
    categories = rp_categories.get_categories(db)
    configuration = rp_settings.get_settings(db)

    return templates.TemplateResponse(
        "pages/crm/propositions/propositions.html",
        context={
            "request": request,
            "current_page": "propositions",
            "title": f"{configuration.brand_name}[CRM] - Propositions",
            "message": message,
            "propositions": propositions,
            "categories": categories,
            "configuration": configuration
        }
    )

# ADD PROPOSITION
@router.get("/propositions/add-proposition")
async def add_proposition_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    categories = rp_categories.get_categories(db)

    return templates.TemplateResponse(
        "pages/crm/propositions/add-proposition.html",
        context={
            "request": request,
            "current_page": "propositions",
            "title": f"{configuration.brand_name}[CRM] - Add proposition",
            "categories": categories,
            "configuration": configuration
        }
    )

# CREATE PROPOSITION POST
@router.post("/propositions/add-proposition/create")
async def create_propositions(
    request: Request,
    image_url: UploadFile = File(...),
    title: str = Form(...),
    description: str = Form(...),
    price: str = Form(...),
    button_text: str = Form(''),
    button_url: str = Form(''),
    category_id: int = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    file_location = save_image(UPLOAD_DIR, image_url)


    new_proposition = PropostionModel(
        title=title,
        description=description,
        price=price,
        button_text=button_text,
        button_url=button_url,
        category_id=category_id,
        image_url=file_location,
    )

    proposition = rp_propositions.create_proposition(new_proposition, db)
    request.session['message'] = 'Proposition was successfully created!'

    return RedirectResponse(url="/crm/propositions", status_code=status.HTTP_302_FOUND)


# UPDATE PROPOSITIONS GET
@router.get("/propositions/{proposition_id}/")
async def update_stock_page(
    request: Request,
    proposition_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)   

    proposition = rp_propositions.get_proposition_by_id(proposition_id, db)
    if not proposition:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    categories = rp_categories.get_categories(db)
    selected_category = rp_categories.get_category_by_id(proposition.category_id, db)

    return templates.TemplateResponse(
        "pages/crm/propositions/update-proposition.html",
        context={
            "request": request,
            "current_page": "propositions",
            "title": f"{configuration.brand_name}[CRM] - Update proposition",
            "proposition": proposition,
            "categories": categories,
            "selected_category": selected_category,
            "configuration": configuration
        }
    )

# UPDATE PROPOSITION POST
@router.post("/propositions/{proposition_id}/update")
async def update_proposition(
    request: Request,
    proposition_id: int,
    image_url: UploadFile | str = File('...'),
    title: str = Form(...),
    description: str = Form(...),
    price: str = Form(...),
    button_text: str = Form(''),
    button_url: str = Form(''),
    category_id: int = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED) 

    proposition = rp_propositions.get_proposition_by_id(proposition_id, db)

    if image_url.filename == '':
        image_path = proposition.image_url
    else:
        delete_old_image(proposition.image_url)
        image_path = save_image(UPLOAD_DIR, image_url)

    new_proposition = PropostionModel(
        title=title,
        description=description,
        price=price,
        button_text=button_text,
        button_url=button_url,
        category_id=category_id,
        image_url=image_path,
    )
    
    proposition = rp_propositions.update_proposition(proposition.id, new_proposition, db)
    request.session['message'] = 'Proposition was successfully updated!'

    return RedirectResponse(url="/crm/propositions", status_code=status.HTTP_302_FOUND)


# DELETE PROPOSITION
@router.get("/propositions/{proposition_id}/delete")
async def delete_sproposition_page(
    request: Request,
    proposition_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED) 
    
    proposition = rp_propositions.get_proposition_by_id(proposition_id, db)

    
    if proposition:
        delete_old_image(proposition.image_url)
        rp_propositions.delete_proposition_by_id(proposition.id, db)
        

        request.session['message'] = 'Proposition was successfully deleted!'
        return RedirectResponse(url="/crm/propositions", status_code=status.HTTP_302_FOUND)