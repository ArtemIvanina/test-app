from fastapi import APIRouter, Form, UploadFile, File, HTTPException, Depends, status, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.config.settings import settings
from src.schemas.stocks_schema import StockModel
from src.repository import rp_stocks, rp_settings
from src.services.authorization import auth_service
from src.utilities.image_actions import save_image, delete_old_image

router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')


UPLOAD_DIR = "static/images/uploads/stocks"

# SLIDES
@router.get("/stocks")
async def slides_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    message = request.session.pop('message', '')

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    stocks = rp_stocks.get_stocks(db)
    system = rp_settings.get_settings(db)

    return templates.TemplateResponse(
        "pages/crm/stocks/stocks.html",
        context={
            "request": request,
            "current_page": "stocks",
            "title": f"{configuration.brand_name}[CRM] - Stocks",
            "message": message,
            "stocks": stocks,
            "settings": system,
            "configuration": configuration
        }
    )

# ADD STOCK
@router.get("/stocks/add-stock")
async def add_stock_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    system = rp_settings.get_settings(db)

    return templates.TemplateResponse(
        "pages/crm/stocks/add-stock.html",
        context={
            "request": request,
            "current_page": "stocks",
            "title": f"{configuration.brand_name}[CRM] - Add stock",
            "settings": system,
            "configuration": configuration
        }
    )


# CREATE STOCK POST
@router.post("/stocks/add-stock/create")
async def create_stocks(
    request: Request,
    image_url: UploadFile = File(...),
    title: str = Form(...),
    discount: str = Form(...),
    subtext: str = Form(''),
    button_text: str = Form(''),
    button_url: str = Form(''),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    file_location = save_image(UPLOAD_DIR, image_url)
    
    new_stock = StockModel(
        title=title,
        discount=discount,
        subtext=subtext,
        button_text=button_text,
        button_url=button_url,
        image_url=file_location,
    )

    stock = rp_stocks.create_stock(new_stock, db)
    request.session['message'] = 'Stock was successfully created!'

    return RedirectResponse(url="/crm/stocks", status_code=status.HTTP_302_FOUND)


# UPDATE STOCK GET
@router.get("/stocks/{stock_id}/")
async def update_stock_page(
    request: Request,
    stock_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    
    stock = rp_stocks.get_stock_by_id(stock_id, db)
    if not stock:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    return templates.TemplateResponse(
        "pages/crm/stocks/update-stock.html",
        context={
            "request": request,
            "current_page": "stocks",
            "title": f"{configuration.brand_name}[CRM] - Update stock",
            "stock": stock,
            "configuration": configuration,
        }
    )

# UPDATE STOCK POST
@router.post("/stocks/{stock_id}/update")
async def create_slides(
    request: Request,
    stock_id: int,
    image_url: UploadFile | str = File('...'),
    title: str = Form(''),
    discount: str = Form(...),
    subtext: str = Form(...),
    button_text: str = Form(...),
    button_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    stock = rp_stocks.get_stock_by_id(stock_id, db)
   
    if image_url.filename == '':
        image_path = stock.image_url
    else:
        delete_old_image(stock.image_url)
        image_path = save_image(UPLOAD_DIR, image_url)

    new_stock = StockModel(
        title=title,
        discount=discount,
        subtext=subtext,
        button_text=button_text,
        button_url=button_url,
        image_url=image_path,
    )
    
    stock = rp_stocks.update_stock(stock_id, new_stock, db)
    request.session['message'] = 'Slide was successfully updated!'

    return RedirectResponse(url="/crm/stocks", status_code=status.HTTP_302_FOUND)


# DELETE STOCK
@router.get("/stocks/{stock_id}/delete")
async def delete_stock_page(
    request: Request,
    stock_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    stock = rp_stocks.get_stock_by_id(stock_id, db)

    if stock:
        delete_old_image(stock.image_url)
        rp_stocks.delete_stock_by_id(stock.id, db)

        request.session['message'] = 'Stock was successfully deleted!'
        return RedirectResponse(url="/crm/stocks", status_code=status.HTTP_302_FOUND)