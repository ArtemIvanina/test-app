from fastapi import APIRouter, Request, status, HTTPException, Depends, Form, UploadFile, File
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from src.db.db import get_db
from src.db.models import User
from src.schemas.slides_schema import SlideModel
from src.repository import rp_slides, rp_settings
from src.services.authorization import auth_service
from src.utilities.image_actions import save_image, delete_old_image


router = APIRouter(prefix="/crm")
templates = Jinja2Templates(directory="templates")
router.mount('/static', StaticFiles(directory="static"), name='static')

UPLOAD_DIR = "static/images/uploads/slides"

# CREATE SLIDE POST
@router.post("/slides/add-slide/create")
async def create_slides(
    request: Request,
    image_url: UploadFile = File(...),
    title: str = Form(''),
    description: str = Form(''),
    button_text: str = Form(...),
    button_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    
    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    file_location = save_image(UPLOAD_DIR, image_url)

    new_slide = SlideModel(
        image_url=file_location,
        title=title,
        description=description,
        button_text=button_text,
        button_url=button_url
    )
    
    slide = rp_slides.create_slide(new_slide, db)
    request.session['message'] = 'Slide was successfully created!'

    return RedirectResponse(url="/crm/slides", status_code=status.HTTP_302_FOUND)


# UPDATE SLIDE POST
@router.post("/slides/{slide_id}/update")
async def create_slides(
    request: Request,
    slide_id: int,
    image_url: UploadFile | str = File('...'),
    title: str = Form(''),
    description: str = Form(''),
    button_text: str = Form(...),
    button_url: str = Form(...),
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    if image_url.filename == '':
        image_path = slide.image_url
    else:
        delete_old_image(slide.image_url)
        image_path = save_image(UPLOAD_DIR, image_url)

    new_slide = SlideModel(
        image_url=image_path,
        title=title,
        description=description,
        button_text=button_text,
        button_url=button_url
    )
    
    slide = rp_slides.update_slide(slide_id, new_slide, db)
    request.session['message'] = 'Slide was successfully updated!'

    return RedirectResponse(url="/crm/slides", status_code=status.HTTP_302_FOUND)

# SLIDES
@router.get("/slides")
async def slides_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    message = request.session.pop('message', '')

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    slides = rp_slides.get_slides(db)

    return templates.TemplateResponse(
        "pages/crm/slides/slides.html",
        context={
            "request": request,
            "current_page": "slides",
            "title": f"{configuration.brand_name}[CRM] - Slides",
            "message": message,
            "slides": slides,
            "configuration": configuration
        }
    )

# ADD SLIDE
@router.get("/slides/add-slide")
async def add_slider_page(
    request: Request,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    return templates.TemplateResponse(
        "pages/crm/slides/add-slide.html",
        context={
            "request": request,
            "current_page": "slides",
            "title": f"{configuration.brand_name}[CRM] - Add slide",
            "configuration": configuration
        }
    )

# UPDATE SLIDE GET
@router.get("/slides/{slide_id}/")
async def update_slide_page(
    request: Request,
    slide_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):
    

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    
    slide = rp_slides.get_slide_by_id(slide_id, db)
    if not slide:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    return templates.TemplateResponse(
        "pages/crm/slides/update-slide.html",
        context={
            "request": request,
            "current_page": "slides",
            "title": f"{configuration.brand_name}[CRM] - Update slide",
            "slide": slide,
            "configuration": configuration
        }
    )

# DELETE SLIDE
@router.get("/slides/{slide_id}/delete")
async def delete_slide_page(
    request: Request,
    slide_id: int,
    current_user: User = Depends(auth_service.get_current_user),
    db: Session = Depends(get_db)):

    configuration = rp_settings.check_init(db)
    if configuration is None:
        response = RedirectResponse(url='/crm/auth/init', status_code=status.HTTP_302_FOUND)
        return response
    if current_user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    
    slide = rp_slides.get_slide_by_id(slide_id, db)
    if slide:
        delete_old_image(slide.image_url)
        rp_slides.delete_slide_by_id(slide.id, db)

        request.session['message'] = 'Slide was successfully deleted!'
        return RedirectResponse(url="/crm/slides", status_code=status.HTTP_302_FOUND)
    
