from sqlalchemy import Column, Integer, String, DateTime, func, ForeignKey, Boolean
from sqlalchemy.orm import declarative_base, relationship

from src.db.db import engine

Base = declarative_base()

# Navigation model
class Navigation(Base):
    __tablename__ = "navigations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    link_text = Column(String(15), nullable=False)
    link_url =Column(String(255), nullable=False)
    
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


# Slide model
class Slide(Base):
    __tablename__ = "slides"

    id = Column(Integer, primary_key=True, autoincrement=True)
    image_url = Column(String(255), nullable=False)
    title = Column(String(50), nullable=True)
    description = Column(String(250), nullable=True)
    button_text = Column(String(20), nullable=False)
    button_url = Column(String(255), nullable=False)

    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class Stock(Base):
    __tablename__ = "stocks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    image_url = Column(String(255), nullable=False)
    title = Column(String(50), nullable=False)
    discount = Column(String(5), nullable=False)
    subtext = Column(String(20), nullable=True)
    button_text = Column(String(20), nullable=False)
    button_url = Column(String(255), nullable=False)

    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())



class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, autoincrement=True)
    category = Column(String(30), unique=True, nullable=False)
    propositions = relationship('Proposition', back_populates='category')
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class Proposition(Base):
    __tablename__ = "propositions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    image_url = Column(String(255), nullable=False)
    title = Column(String(50), nullable=False)
    description = Column(String(250), nullable=True)
    price = Column(String(10), nullable=False)
    button_text = Column(String(20), nullable=False)
    button_url = Column(String(255), nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"))  
    category = relationship("Category", back_populates="propositions")
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class Feedback(Base):
    __tablename__ = "feedbacks"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(70), nullable=False)
    rating = Column(Integer, nullable=True)
    comment = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())




class Social(Base):
    __tablename__ = 'socials'

    id = Column(Integer, primary_key=True, autoincrement=True)
    fa_icon_class = Column(String(70), nullable=False)
    fa_icon_url = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())



class ApplicationSettings(Base):
    __tablename__ = "application_settings"
    id = Column(Integer, primary_key=True, autoincrement=True)

    currency = Column(String(10), nullable=False)
    brand_name = Column(String(50), nullable=False)
    header_button_text = Column(String(20), nullable=False)
    header_button_url = Column(String(255), nullable=False)
    propositions_button_text = Column(String(20), nullable=False)
    propositions_button_url = Column(String(255), nullable=False)
    preview_image = Column(String(255), nullable=False)
    preview_title = Column(String(50), nullable=False)
    preview_description = Column(String, nullable=True)
    preview_button_text = Column(String(20), nullable=False)
    preview_button_url = Column(String(255), nullable=False)
    map_api_key = Column(String(255), nullable=True)
    map_coordinate_latitude = Column(String(50), nullable=True)
    map_coordinate_longitude = Column(String(50), nullable=True)
    map_zoom = Column(String(3), nullable=True)
    footer_contact_us_location_text = Column(String(30), nullable=False)
    footer_contact_us_location_url = Column(String(255), nullable=True)
    footer_contact_us_call_text = Column(String(30), nullable=False)
    footer_contact_us_call_url = Column(String(255), nullable=True)
    footer_contact_us_mail_text = Column(String(30), nullable=False)
    footer_contact_us_mail_url = Column(String(255), nullable=True)
    footer_social_description = Column(String(150), nullable=True)
    footer_shedule_days_text = Column(String(50), nullable=True)
    footer_shedule_time_text = Column(String(50), nullable=True)
    footer_copyright_text = Column(String(50), nullable=True)
    powered_by_text = Column(String(50), nullable=True)
    powered_by_url = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    email = Column(String(200), nullable=False, unique=True)
    password = Column(String(255), nullable=False)
    refresh_token = Column(String(255), nullable=True)
    security = Column(Boolean, default=True)
    key = Column(String(10), nullable=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
