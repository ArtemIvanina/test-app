import logging
from pathlib import Path

from fastapi_mail import ConnectionConfig, MessageSchema, FastMail, MessageType
from pydantic import EmailStr

from src.config.settings import settings
from src.services.authorization import auth_service

# Logging settings
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

conf = ConnectionConfig(
    MAIL_USERNAME=settings.mail_username,
    MAIL_PASSWORD=settings.mail_password,
    MAIL_FROM=settings.mail_from,
    MAIL_PORT=settings.mail_port,
    MAIL_SERVER=settings.mail_server,
    MAIL_FROM_NAME="Security Team",
    MAIL_STARTTLS=False,
    MAIL_SSL_TLS=True,
    USE_CREDENTIALS=True,
    VALIDATE_CERTS=False, 
    TEMPLATE_FOLDER=str(Path("src/services/templates"))
)

async def send_email_login_confirmation(email: EmailStr, host: str, secret_key: str, subject: str, template: str):
    try:
        token_verification = auth_service.create_email_token({"sub": email})
        
        message = MessageSchema(
            subject=subject,
            recipients=[email],
            template_body={"host": host, "user_email": email,"secret_key": secret_key, "token": token_verification},
            subtype=MessageType.html
        )
        fm = FastMail(conf)
        await fm.send_message(message=message, template_name=template)
        logger.info(f"Email sent successfully to {email}")

    except ConnectionError as error:
        logger.error(f"Connection error: {error}")

    except Exception as ex:
        logger.error(f"An unexpected error occurred: {ex}")

