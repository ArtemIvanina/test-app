import os
from datetime import datetime

from fastapi import UploadFile

from src.config.config import DOMAIN





def save_image(upload_dir: str, image: UploadFile):
    if image.filename != '':
        # Получаем текущее время в нужном формате
        current_time = datetime.now().strftime("%H_%M_%S__%d_%m_%Y")
        # Создаем путь к файлу, подставляя отформатированное время и имя файла
        file_location = os.path.join(upload_dir, f"{current_time}_{image.filename}")
        
        # Убедимся, что каталог существует
        os.makedirs(upload_dir, exist_ok=True)

        # Записываем файл
        with open(file_location, "wb") as file:
            file.write(image.file.read())

        return file_location
    return None


    
    


def delete_old_image(path_to_old_image):
    try:
        os.remove(path_to_old_image)
    except Exception:
        pass
