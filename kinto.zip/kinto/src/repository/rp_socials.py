from sqlalchemy.orm import Session

from src.db.models import Social
from src.schemas.socials_schema import SocialModel

def get_socials(db: Session):
    socials = db.query(Social).all()
    return socials


def get_social_by_id(social_id: int, db: Session):
    social = db.query(Social).filter(Social.id == social_id).first()
    return social

def create_social(body: SocialModel, db: Session):
    social = Social(**body.model_dump())
    db.add(social)
    db.commit()
    db.refresh(social)
    return social


def update_social(social_id: int, body: SocialModel, db: Session):
    social = db.query(Social).filter(Social.id == social_id).first()
    if social:
        social.fa_icon_class=body.fa_icon_class
        social.fa_icon_url=body.fa_icon_url

        db.add(social)
        db.commit()
        db.refresh(social)

def delete_social_by_id(social_id: int, db: Session):
    social = db.query(Social).filter(Social.id == social_id).first()
    if social:
        db.delete(social)
        db.commit()
        return True
    return False