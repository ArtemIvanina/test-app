from sqlalchemy.orm import Session

from src.db.models import Slide
from src.schemas.slides_schema import SlideModel

def get_slides(db: Session):
    slides = db.query(Slide).all()
    return slides


def get_slide_by_id(slide_id: int, db: Session):
    slide = db.query(Slide).filter(Slide.id == slide_id).first()
    return slide

def create_slide(body: SlideModel, db: Session):
    slide = Slide(**body.model_dump())
    db.add(slide)
    db.commit()
    db.refresh(slide)
    return slide


def update_slide(slide_id: int, body: SlideModel, db: Session):
    slide = db.query(Slide).filter(Slide.id == slide_id).first()
    if slide:
        slide.image_url = body.image_url
        slide.title = body.title
        slide.description = body.description
        slide.button_text = body.button_text
        slide.button_url = body.button_url

        db.add(slide)
        db.commit()
        db.refresh(slide)

def delete_slide_by_id(slide_id: int, db: Session):
    slide = db.query(Slide).filter(Slide.id == slide_id).first()
    if slide:
        db.delete(slide)
        db.commit()
        return True
    return False