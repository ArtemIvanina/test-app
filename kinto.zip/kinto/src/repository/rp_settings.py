from sqlalchemy.orm import Session
from sqlalchemy import select

from src.db.models import Navigation, ApplicationSettings
from src.schemas.navigations_schema import NavigationModel
from src.schemas.application_settings_schema import AplicationSettingsModel, AppGeneralModel, AppPreviewModel, AppFooterModel, AppHeaderModel, AppMapModel, AppPropositionButtonModel


def check_init(db: Session):
    initialization = (db.execute(select(ApplicationSettings).limit(1))).scalar()
    if initialization is None:
        return None
    return initialization 
    
def create_application_settings(body: AplicationSettingsModel, db: Session):
    navigation = ApplicationSettings(**body.model_dump())
    db.add(navigation)
    db.commit() 
    db.refresh(navigation)
    return navigation

def get_settings(db: Session):
    system = db.query(ApplicationSettings).first()
    return system

def get_navigation(db: Session):
    navigation = db.query(Navigation).all()
    return navigation

def get_navigation_by_id(navigation_id: int, db: Session):
    navigation = db.query(Navigation).filter(Navigation.id == navigation_id).first()
    return navigation

def create_navigation(body: NavigationModel, db: Session):
    navigation = Navigation(**body.model_dump())
    db.add(navigation)
    db.commit()
    db.refresh(navigation)
    return navigation

def update_navigation(navigation_id: int, body: NavigationModel, db: Session):
    navigation = db.query(Navigation).filter(Navigation.id == navigation_id).first()
    if navigation:
        navigation.link_text = body.link_text
        navigation.link_url = body.link_url

        db.add(navigation)
        db.commit()
        db.refresh(navigation)

def delete_navigation_by_id(navigation_id: int, db: Session):
    navigation = db.query(Navigation).filter(Navigation.id == navigation_id).first()
    if navigation:
        db.delete(navigation)
        db.commit()
        return True
    return False





def update_general(body: AppGeneralModel, db: Session):
    general = db.query(ApplicationSettings).first()
    if general:
        general.currency = body.currency
        general.brand_name = body.brand_name

        db.add(general)
        db.commit()
        db.refresh(general)


def update_proposition_button(body: AppPropositionButtonModel, db: Session):
    proposition_button = db.query(ApplicationSettings).first()
    if proposition_button:
        proposition_button.propositions_button_text = body.propositions_button_text
        proposition_button.propositions_button_url = body.propositions_button_url

        db.add(proposition_button)
        db.commit()
        db.refresh(proposition_button)

def update_preview(body: AppPreviewModel, db: Session):
    preview = db.query(ApplicationSettings).first()
    if preview:
        preview.preview_image = body.preview_image
        preview.preview_title = body.preview_title
        preview.preview_description = body.preview_description
        preview.preview_button_text = body.preview_button_text
        preview.preview_button_url = body.preview_button_url

        db.add(preview)
        db.commit()
        db.refresh(preview)

def update_header(body: AppHeaderModel, db: Session):
    header = db.query(ApplicationSettings).first()
    if header:
        header.header_button_text = body.header_button_text
        header.header_button_url = body.header_button_url

        db.add(header)
        db.commit()
        db.refresh(header)


def update_map(body: AppMapModel, db: Session):
    google_map = db.query(ApplicationSettings).first()
    if google_map:
        
        google_map.map_api_key = body.map_api_key
        google_map.map_coordinate_latitude = body.map_coordinate_latitude
        google_map.map_coordinate_longitude = body.map_coordinate_longitude
        google_map.map_zoom = body.map_zoom

        db.add(google_map)
        db.commit()
        db.refresh(google_map)


def update_footer(body: AppFooterModel, db: Session):
    footer = db.query(ApplicationSettings).first()
    if footer:
        footer.footer_contact_us_location_text = body.footer_contact_us_location_text
        footer.footer_contact_us_location_url = body.footer_contact_us_location_url
        footer.footer_contact_us_call_text = body.footer_contact_us_call_text
        footer.footer_contact_us_call_url = body.footer_contact_us_call_url
        footer.footer_contact_us_mail_text = body.footer_contact_us_mail_text
        footer.footer_contact_us_mail_url = body.footer_contact_us_mail_url
        footer.footer_social_description = body.footer_social_description
        footer.footer_shedule_days_text = body.footer_shedule_days_text
        footer.footer_shedule_time_text = body.footer_shedule_time_text
        footer.footer_copyright_text = body.footer_copyright_text
        footer.powered_by_text = body.powered_by_text
        footer.powered_by_url = body.powered_by_url
        db.add(footer)
        db.commit()
        db.refresh(footer)