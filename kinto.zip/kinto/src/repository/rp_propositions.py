from sqlalchemy.orm import Session

from src.db.models import Proposition
from src.schemas.propositions_schema import PropostionModel

def get_propositions(db: Session):
    propositions = db.query(Proposition).all()
    return propositions


def get_proposition_by_id(proposition_id: int, db: Session):
    proposition = db.query(Proposition).filter(Proposition.id == proposition_id).first()
    return proposition

def create_proposition(body: PropostionModel, db: Session):
    proposition = Proposition(**body.model_dump())
    db.add(proposition)
    db.commit()
    db.refresh(proposition)
    return proposition


def update_proposition(proposition_id: int, body: PropostionModel, db: Session):
    proposition = db.query(Proposition).filter(Proposition.id == proposition_id).first()
    if proposition:
        proposition.title = body.title
        proposition.description = body.description
        proposition.price = body.price
        proposition.button_text = body.button_text
        proposition.button_url = body.button_url
        proposition.category_id = body.category_id
        proposition.image_url = body.image_url

        db.add(proposition)
        db.commit()
        db.refresh(proposition)


def delete_proposition_by_id(proposition_id: int, db: Session):
    proposition = db.query(Proposition).filter(Proposition.id == proposition_id).first()
    if proposition:
        db.delete(proposition)
        db.commit()
        return True
    return False