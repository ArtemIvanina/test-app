from sqlalchemy.orm import Session

from src.db.models import Feedback
from src.schemas.feedbacks_schema import FeedbackModel

def get_feedbacks(db: Session):
    feedbacks = db.query(Feedback).all()
    return feedbacks


def get_feedback_by_id(feedback_id: int, db: Session):
    feedback = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    return feedback

def create_feedback(body: FeedbackModel, db: Session):
    feedback = Feedback(**body.model_dump())
    db.add(feedback)
    db.commit()
    db.refresh(feedback)
    return feedback


def update_feedback(feedback_id: int, body: FeedbackModel, db: Session):
    feedback = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    if feedback:

        feedback.username = body.username
        feedback.rating = body.rating
        feedback.comment = body.comment

        db.add(feedback)
        db.commit()
        db.refresh(feedback)

def delete_feedback_by_id(feedback_id: int, db: Session):
    feedback = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    if feedback:
        db.delete(feedback)
        db.commit()
        return True
    return False