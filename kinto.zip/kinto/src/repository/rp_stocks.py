from sqlalchemy.orm import Session

from src.db.models import Stock
from src.schemas.stocks_schema import StockModel

def get_stocks(db: Session):
    stocks = db.query(Stock).all()
    return stocks


def get_stock_by_id(stock_id: int, db: Session):
    stock = db.query(Stock).filter(Stock.id == stock_id).first()
    return stock

def create_stock(body: StockModel, db: Session):
    stock = Stock(**body.model_dump())
    db.add(stock)
    db.commit()
    db.refresh(stock)
    return stock


def update_stock(stock_id: int, body: StockModel, db: Session):
    stock = db.query(Stock).filter(Stock.id == stock_id).first()
    if stock:

        stock.image_url = body.image_url
        stock.title = body.title
        stock.discount = body.discount
        stock.subtext = body.subtext
        stock.button_text = body.button_text
        stock.button_url = body.button_url

        db.add(stock)
        db.commit()
        db.refresh(stock)

def delete_stock_by_id(stock_id: int, db: Session):
    stock = db.query(Stock).filter(Stock.id == stock_id).first()
    if stock:
        db.delete(stock)
        db.commit()
        return True
    return False