from sqlalchemy.orm import Session
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from src.db.models import User
from src.schemas.users_schema import UserModel

def create_user(body: UserModel , db: Session) -> User:
    new_user = User(**body.model_dump()) 
        
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

def update_key(user: User, key: str, db: Session) -> None:
    if key:
        user.key = key
        db.commit()

def update_token(user: User, refresh_token: str, db: Session) -> None:
    if refresh_token:
        user.refresh_token = refresh_token
        db.commit()

def update_login_confirmation(user: User, db: Session) -> None:
    if user.security:
        user.security = False
    else:
        user.security = True
    db.commit()

def get_user_by_email(email: str, db: Session):
    user = db.query(User).filter(User.email == email).first()
    return user