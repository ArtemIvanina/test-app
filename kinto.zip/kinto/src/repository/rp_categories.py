from sqlalchemy.orm import Session

from src.db.models import Category
from src.schemas.categories_schema import CategoryModel

def get_categories(db: Session):
    categories = db.query(Category).all()
    return categories


def get_category_by_id(category_id: int, db: Session):
    category = db.query(Category).filter(Category.id == category_id).first()
    return category

def create_category(body: CategoryModel, db: Session):
    category = Category(**body.model_dump())
    db.add(category)
    db.commit()
    db.refresh(category)
    return category


def update_category(category_id: int, body: CategoryModel, db: Session):
    category = db.query(Category).filter(Category.id == category_id).first()
    if category:
        category.category = body.category

        db.add(category)
        db.commit()
        db.refresh(category)

def delete_category_by_id(category_id: int, db: Session):
    category = db.query(Category).filter(Category.id == category_id).first()
    if category:
        db.delete(category)
        db.commit()
        return True
    return False