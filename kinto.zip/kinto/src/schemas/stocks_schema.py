from pydantic import BaseModel
from fastapi import UploadFile

class StockModel(BaseModel):
    image_url: str
    title: str
    discount: str
    subtext: str
    button_text: str
    button_url: str
    

class StockResponse(BaseModel):
    id: int
    image_url: str
    title: str
    discount: str
    subtext: str
    button_text: str
    button_url: str