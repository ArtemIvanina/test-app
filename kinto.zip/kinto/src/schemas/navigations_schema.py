from pydantic import BaseModel

class NavigationModel(BaseModel):
    link_text: str
    link_url: str

class NavigationResponse(BaseModel):
    id: int
    link_text: str
    link_url: str
