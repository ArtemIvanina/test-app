from pydantic import BaseModel

class AplicationSettingsModel(BaseModel):
    currency: str
    brand_name: str
    header_button_text: str
    header_button_url: str
    propositions_button_text: str
    propositions_button_url: str
    preview_image: str
    preview_title: str
    preview_description: str
    preview_button_text: str
    preview_button_url: str
    map_api_key: str
    map_coordinate_latitude: str
    map_coordinate_longitude: str
    map_zoom: str
    footer_contact_us_location_text: str
    footer_contact_us_location_url: str
    footer_contact_us_call_text: str
    footer_contact_us_call_url: str
    footer_contact_us_mail_text: str
    footer_contact_us_mail_url: str
    footer_social_description: str
    footer_shedule_days_text: str
    footer_shedule_time_text: str
    footer_copyright_text: str
    powered_by_text: str
    powered_by_url: str

class AplicationSettingsResponse(BaseModel):
    id: int
    currency: str
    brand_name: str
    header_button_text: str
    header_button_url: str
    propositions_button_text: str
    propositions_button_url: str
    preview_image: str
    preview_title: str
    preview_description: str
    preview_button_text: str
    preview_button_url: str
    map_api_key: str
    map_coordinate_latitude: str
    map_coordinate_longitude: str
    map_zoom: str
    footer_contact_us_location_text: str
    footer_contact_us_location_url: str
    footer_contact_us_call_text: str
    footer_contact_us_call_url: str
    footer_contact_us_mail_text: str
    footer_contact_us_mail_url: str
    footer_social_description: str
    footer_shedule_days_text: str
    footer_shedule_time_text: str
    footer_copyright_text: str
    powered_by_text: str
    powered_by_url: str




class AppGeneralModel(BaseModel):
    currency: str
    brand_name: str

class AppHeaderModel(BaseModel):
    header_button_text: str
    header_button_url: str

class AppPreviewModel(BaseModel):
    preview_image: str
    preview_title: str
    preview_description: str
    preview_button_text: str
    preview_button_url: str

class AppPropositionButtonModel(BaseModel):
    propositions_button_text: str
    propositions_button_url: str

class AppMapModel(BaseModel):
    map_api_key: str
    map_coordinate_latitude: str
    map_coordinate_longitude: str
    map_zoom: str


class AppFooterModel(BaseModel):
    footer_contact_us_location_text: str
    footer_contact_us_location_url: str

    footer_contact_us_call_text: str
    footer_contact_us_call_url: str

    footer_contact_us_mail_text: str
    footer_contact_us_mail_url: str

    footer_social_description: str
    footer_shedule_days_text: str
    footer_shedule_time_text: str
    
    footer_copyright_text: str

    powered_by_text: str
    powered_by_url: str

