from pydantic import BaseModel, EmailStr

class UserModel(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: EmailStr
    password: str
    refresh_token: str