from pydantic import BaseModel

class SocialModel(BaseModel):
    fa_icon_class: str
    fa_icon_url: str

class SocialResponse(BaseModel):
    id: int
    fa_icon_class: str
    fa_icon_url: str
