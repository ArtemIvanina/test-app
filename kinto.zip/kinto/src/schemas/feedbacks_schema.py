from pydantic import BaseModel
from fastapi import UploadFile

class FeedbackModel(BaseModel):
    username: str
    rating: int
    comment: str
    

class FeedbackResponse(BaseModel):
    id: int
    username: str
    rating: int
    comment: str
    