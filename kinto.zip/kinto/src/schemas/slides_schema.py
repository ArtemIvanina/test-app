from pydantic import BaseModel

class SlideModel(BaseModel):
    image_url: str
    title: str
    description: str
    button_text: str
    button_url: str

class SlideResponse(BaseModel):
    id: int
    image_url: str
    title: str
    description: str
    button_text: str
    button_url: str
