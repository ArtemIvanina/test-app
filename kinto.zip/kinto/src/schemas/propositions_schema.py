from pydantic import BaseModel

class PropostionModel(BaseModel):
    image_url: str
    title: str
    description: str
    price: str
    button_text: str
    button_url: str
    category_id: int  

class PropostionResponse(BaseModel):
    id: int
    image_url: str
    title: str
    description: str
    price: str
    button_text: str
    button_url: str
    category_id: int  