from pydantic import BaseModel

class CategoryModel(BaseModel):
    category: str

class CategoryResponse(BaseModel):
    id: int
    category: str
