document.addEventListener('DOMContentLoaded', function() {
    const stockImage = document.getElementById('content-image');
    const imageUrlInput = document.getElementById('image_url');
    const stockImagePreview = document.getElementById('content-image-preview');
    const defaultImageSrc = stockImagePreview.src;  // Store the default image source

    stockImage.addEventListener('click', function() {
        imageUrlInput.click();
    });

    imageUrlInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                stockImagePreview.src = e.target.result;
            }
            reader.readAsDataURL(file);
        } else {
            // If no file is selected, revert to the default image
            stockImagePreview.src = defaultImageSrc;
        }
    });

    imageUrlInput.addEventListener('blur', function() {
        // If no file is selected, revert to the default image
        if (!this.files.length) {
            stockImagePreview.src = defaultImageSrc;
        }
    });
});