let prefounters = document.querySelectorAll(".prefounter")
if (prefounters) {
    prefounters.forEach(element => {
        element.addEventListener("keyup", function() {
            const parent = element.closest('.input-field');
            if (parent) {
                parent.querySelector(".prefounter_count span").textContent = element.value.length;
            }
        })
    })
}