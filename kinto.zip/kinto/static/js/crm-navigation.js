document.addEventListener('DOMContentLoaded', function () {
    var menuBtn = document.querySelector('.menu-btn');
    var body = document.body;
    var isActive = localStorage.getItem('activeMobileMenu');

    if (isActive === 'true') {
        body.classList.add('active-mobile-menu');
    }
    menuBtn.addEventListener('click', function () {
        body.classList.toggle('active-mobile-menu');
        var isActive = body.classList.contains('active-mobile-menu');
        localStorage.setItem('activeMobileMenu', isActive.toString());
    });
});