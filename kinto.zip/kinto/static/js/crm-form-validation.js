document.querySelectorAll('.require-input').forEach(function(element) {
    element.addEventListener('input', validateForm);
});
function validateForm() {
    let isValid = true;
    document.querySelectorAll('.require-input').forEach(function(input) {
        if (!input.value.trim()) {
            isValid = false;
        }
    });

    const submitBtn = document.getElementById('submit-btn');
    if (isValid) {
        submitBtn.disabled = false;
        submitBtn.classList.remove('disabled-btn');
    } else {
        submitBtn.disabled = true;
        submitBtn.classList.add('disabled-btn');
    }
}