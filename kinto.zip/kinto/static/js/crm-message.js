document.addEventListener('DOMContentLoaded', function() {
    const messageElement = document.getElementById('message');
    
    if (messageElement) {
        // Добавляем класс show для запуска анимации
        messageElement.classList.add('show');

        // Удаляем элемент через 3 секунды
        setTimeout(() => {
            messageElement.classList.remove('show');
            
            // Дополнительная задержка для завершения анимации перед удалением из DOM
            setTimeout(() => {
                messageElement.style.display = 'none';
            }, 500); // Должно совпадать с длительностью transition
        }, 5000); // Время показа сообщения
    }
    
});