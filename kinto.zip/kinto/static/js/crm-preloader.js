document.addEventListener('DOMContentLoaded', function() {
    const preloader = document.getElementById('preloader');

    // Hide preloader and show main content after page load
    window.addEventListener('load', function() {
        setTimeout(() => {
            preloader.style.display = "none"
        }, 500);
    });
});