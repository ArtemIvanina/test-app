document.querySelector("#category").addEventListener("input", function() {
    const inputValue = this.value.toLowerCase();
    let exists = false;
    document.querySelectorAll(".exist_categories p").forEach(element => {
        if (inputValue === element.textContent.toLowerCase()) {
            exists = true;
        }
    });
    const errorElement = document.querySelector(".exist-error");
    const saveButton = document.querySelector("#submit-btn");
    if (exists) {
        errorElement.style.display = "block";
        errorElement.innerHTML = `The category with name ${this.value} already exists`;
        saveButton.disabled = true;
        saveButton.classList.add("disabled-btn")
    } else {
        errorElement.style.display = "none";
        errorElement.innerHTML = "";
        saveButton.disabled = false;
        saveButton.classList.remove("disabled-btn")
    }
});