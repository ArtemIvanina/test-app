from fastapi import FastAPI, Request, Depends, status, HTTPException
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from sqlalchemy import text
from starlette.middleware.sessions import SessionMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException


from src.db.db import get_db
from src.db.models import ApplicationSettings, User
from src.routes import slides, crm_settings, auth, stocks, categories, propositions, dashboard, socials, feedbacks
from src.config.settings import settings
from src.repository import rp_propositions, rp_categories, rp_settings, rp_slides, rp_stocks, rp_socials, rp_feedbacks
from src.services.authorization import auth_service


app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
app.add_middleware(SessionMiddleware, secret_key=settings.secret_key)

@app.exception_handler(StarletteHTTPException)
async def custom_http_exception_handler(request: Request, exc: StarletteHTTPException):
    if exc.status_code == status.HTTP_404_NOT_FOUND:
        return templates.TemplateResponse("pages/exceptions/page.html", {"request": request, "error_message": "404"}, status_code=exc.status_code)
    elif exc.status_code == status.HTTP_401_UNAUTHORIZED:
        return templates.TemplateResponse("pages/exceptions/page.html", {"request": request, "error_message": "401"}, status_code=exc.status_code)
    return HTMLResponse(content=str(exc.detail), status_code=exc.status_code)

templates = Jinja2Templates(directory="templates")

@app.get("/")
async def root(request: Request, db: Session = Depends(get_db)):
    
    navigations = rp_settings.get_navigation(db)
    slides = rp_slides.get_slides(db)
    stocks = rp_stocks.get_stocks(db)
    categories = rp_categories.get_categories(db)
    propositions = rp_propositions.get_propositions(db)
    configuration = rp_settings.get_settings(db)
    socials = rp_socials.get_socials(db)
    feedbacks = rp_feedbacks.get_feedbacks(db)

    return templates.TemplateResponse(
        "index.html",
        context={
            "request": request,
            "navigations": navigations,
            "slides": slides,
            "stocks": stocks,
            "categories": categories,
            "propositions": propositions,
            "configuration": configuration,
            "socials": socials,
            "feedbacks": feedbacks
        }
    )
    

@app.get('/api/healthchecker')
def healthchecker(db: Session = Depends(get_db)):
    try:
        result = db.execute(text("SELECT 1")).fetchone()
        if result is None:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Database configured is not correctly!")
        return {"message": "Database correctly working!"}
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"{e}")
    


app.include_router(slides.router)
app.include_router(crm_settings.router)
app.include_router(auth.router)
app.include_router(stocks.router)
app.include_router(categories.router)
app.include_router(propositions.router)
app.include_router(dashboard.router)
app.include_router(socials.router)
app.include_router(feedbacks.router)